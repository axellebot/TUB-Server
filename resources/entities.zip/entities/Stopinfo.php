<?php

namespace AppBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * StopInfo
 *
 * @ORM\Table(name="StopInfo")
 * @ORM\Entity
 */
class StopInfo
{

    /**
     * @var string
     *
     * @ORM\Column(name="id", type="string", length=255)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $id;

    /**
     * @ORM\ManyToOne(targetEntity="Stop", inversedBy="stopInfo")
     * @ORM\JoinColumn(name="stop_id", referencedColumnName="id")
     */
    private $stop;

    /**
     * @ORM\ManyToOne(targetEntity="Path", inversedBy="stopInfo")
     * @ORM\JoinColumn(name="path_id", referencedColumnName="id")
     */
    private $path;


    /**
     * @var \Doctrine\Common\Collections\Collection
     *
     * @ORM\OneToMany(targetEntity="Schedule", mappedBy="stopInfo")
     */
    private $schedules;

    /**
     * Constructor
     */
    public function __construct()
    {
        $this->schedules = new \Doctrine\Common\Collections\ArrayCollection();
    }

}
