<?php

namespace AppBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * Path
 *
 * @ORM\Table(name="Path")
 * @ORM\Entity
 */
class Path
{

    /**
     * @var string
     *
     * @ORM\Column(name="id", type="string", length=255)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="name", type="string", length=255, nullable=false)
     */
    private $name;

    /**
     * @var string
     *
     * @ORM\Column(name="direction", type="string", length=255, nullable=false)
     */
    private $direction;

    /**
     * @var boolean
     *
     * @ORM\Column(name="available", type="boolean", nullable=true)
     */
    private $available;


    /**
     * @var \Doctrine\Common\Collections\Collection
     *
     * @ORM\OneToMany(targetEntity="StopInfo", mappedBy="path")
     */
    private $stopInfos;

    /**
     * Constructor
     */
    public function __construct()
    {
        $this->stopInfos = new \Doctrine\Common\Collections\ArrayCollection();
    }

}
